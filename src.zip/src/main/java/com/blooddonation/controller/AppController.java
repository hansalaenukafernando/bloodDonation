package com.blooddonation.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AppController {

    @GetMapping("/role")
    public String viewRolePage(Model model) {
        model.addAttribute("activePage", "role");
        return "role";
    }
}